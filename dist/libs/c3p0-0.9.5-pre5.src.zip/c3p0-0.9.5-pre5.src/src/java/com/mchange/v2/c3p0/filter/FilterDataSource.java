/*
 * Distributed as part of c3p0 v.0.9.5-pre5
 *
 * Copyright (C) 2013 Machinery For Change, Inc.
 *
 * Author: Steve Waldman <swaldman@mchange.com>
 *
 * This library is free software; you can redistribute it and/or modify
 * it under the terms of EITHER:
 *
 *     1) The GNU Lesser General Public License (LGPL), version 2.1, as 
 *        published by the Free Software Foundation
 *
 * OR
 *
 *     2) The Eclipse Public License (EPL), version 1.0
 *
 * You may choose which license to accept if you wish to redistribute
 * or modify this work. You may offer derivatives of this work
 * under the license you have chosen, or you may provide the same
 * choice of license which you have been offered here.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * You should have received copies of both LGPL v2.1 and EPL v1.0
 * along with this software; see the files LICENSE-EPL and LICENSE-LGPL.
 * If not, the text of these licenses are currently available at
 *
 * LGPL v2.1: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
 *  EPL v1.0: http://www.eclipse.org/org/documents/epl-v10.php 
 * 
 */

package com.mchange.v2.c3p0.filter;

import java.io.PrintWriter;
import java.lang.String;
import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.DataSource;


public abstract class FilterDataSource implements DataSource
{
    protected DataSource inner;

    public FilterDataSource(DataSource inner)
    {
       this.inner = inner;
    }

    public Connection getConnection() throws SQLException
    {
        return inner.getConnection();
    }

    public Connection getConnection(String a, String b) throws SQLException
    {
        return inner.getConnection(a, b);
    }

    public PrintWriter getLogWriter() throws SQLException
    {
        return inner.getLogWriter();
    }

    public int getLoginTimeout() throws SQLException
    {
        return inner.getLoginTimeout();
    }

    public void setLogWriter(PrintWriter a) throws SQLException
    {
        inner.setLogWriter(a);
    }

    public void setLoginTimeout(int a) throws SQLException
    {
        inner.setLoginTimeout(a);
    }

}

